// JavaScript Document
 $(function(){
	  $("#B_bg li:gt(0)").css({display:"none"});
     var current = 0;
	 var cursor  = 0;
	 var list = $("#icon > li");
	 list.each(function(index, element) {
        $(this).mouseover(function(){
			$(this).addClass("on");
			list.not(this).removeClass("on");
			$("#B_bg >li").not($("#B_bg >li").eq(list.lenth)).fadeOut(0);
			$("#B_bg > li").eq(index).fadeIn(200);			
			$("#B_bg >li").not($("#B_bg >li").eq(index)).fadeOut(500);			
			cursor = index;
			current = index;
			}) 
			  
	   })
	   setInterval(function(){
			cursor++;
		   if(cursor >list.length-1){
					cursor = 0;
				}
			list.eq(cursor).trigger("mouseover");
			
		   },5000)
	   
	   
	   //产品中心的选项卡   outerWidth(true)这个true是用来加上边距，outerWidth() 方法返回第一个匹配元素的外部宽度，意思获取宽度还要加上边距+边框
	   $(function(){
               	var pro_ul = $('.product .list>ul>li').outerWidth(true)*$('.product .list>ul>li').length;
               	 $('.product .list>ul').width(pro_ul);//设置.product .list>ul的宽度为pro_ul一样大；
               	 $('.product .buttom li').click(function(){
               	        var i = $(this).index()
               	        var sum = $('.product .list>ul>li').outerWidth(true)*4;
               	 $(".product .list>ul").animate({"marginLeft":-i*sum+"px"},700)
               	 $(this).addClass('on').siblings('li').removeClass('on')
               			})
             		})
	   
	   
	   
	   
	   
	   
	        
            	$(function(){
            		$('.play-icon').click(function(){
            			$(this).parent('video_pic').animate({left:'-547px'},700)
            			$(this).siblings('span').animate({left:'-547px'},700)
            			$(this).animate({left:'-547px'},700)
            			$('.video').animate({left:'0px'},700)
            		})
            	})
           
            
				    	function _(id){
				    		return document.getElementById(id);
				    	}
				    	var obj = document.getElementById('obj');
				       	window.onload = function(){
				       		var play = "<img src='images/play.png' width='15%' alt='' id='img_play' />",
				    		stop = "<img src='images/stop.png' width='15%' alt='' id='img_stop' />",
				    		reset = "<img src='images/reset.png' width='15%' alt='' id='img_reset' />"
				       		var b_v = navigator.appVersion;
							var IE8 = b_v.search(/MSIE 8/i) != -1;
							var IE7 = b_v.search(/MSIE 7/i) != -1;
				       		if(IE8||IE7){
				       			if(obj.IsPlaying()){
				           			obj.StopPlay();
				           		}
				           		var a = document.createElement('i')
				           		a.setAttribute('id','play')
				           		a.innerHTML = play+stop+reset
				           		a.setAttribute('href','javascript:;')
				           		document.getElementById('video-play').appendChild(a)
				           		var t;
				           		
				           		var x = 0;
				           		var span = document.createElement('span');
				           		var i = document.createElement('i');
				           		span.setAttribute('id','pro');
				           		span.appendChild(i)
				           		document.getElementById('video-play').appendChild(span)
				           		var sp = document.createElement('span');
				           		sp.setAttribute('class','sp_secode')
				           		sp.innerHTML = "<span id='minute'>00</span>:<span id='second'>00</span>"; 
				           		
				           		document.getElementById('video-play').appendChild(sp)
				           		function time(){
				           			var sum = parseInt(obj.TotalFrames/24);
				           			if(sum/x == 1){//
				           				obj.stopPlay();
				           				clearInterval(t)
				           				x = 0;
				           			}else{
				           				_("second").innerHTML++;
				           				x++
				           				i.style.width = parseFloat(x/sum*100)+"%";
				           				if(_("second").innerHTML<=59){
				           					if(_("second").innerHTML<10){
				           						_("second").innerHTML = "0"+_("second").innerHTML
					           				}else{
					           					_("second").innerHTML = _("second").innerHTML
					           				}
				           				}else{
				           					var mSum = parseInt(_('minute').innerHTML)+1
				           					if(parseInt(_('minute').innerHTML)<11){
				           						_('minute').innerHTML ="0"+parseInt(mSum) ;
				           					}else{
				           						_('minute').innerHTML =mSum ;
				           					}
				           					
				           					_("second").innerHTML = 00
				           				}
				           				
				           			}
				           		}
				           		_('img_play').onclick = function(){
				           			obj.play();
					       			t = setInterval(time,1000) 
					       			x = 0;
				           		}
				           		_('img_stop').onclick = function(){
				       				obj.StopPlay();
						       		clearInterval(t)
				       			}
				           		_('img_reset').onclick = function(){
				           			obj.StopPlay();
						       		clearInterval(t)
				           			_("second").innerHTML = "00";
					       			i.style.width = 0+"%";
				           		}
				           	}
					    }	
				
  
 
 });
  
 
               		
     