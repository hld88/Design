// JavaScript Document
$(document).ready(function(){
	var lun = null;
	var bool=true;
	var liLen=$("#pro li").length;/* li个数*/
	var liWidth=$("#pro li").eq(0).outerWidth(true);
	    $("#pro ul").css({"width":liLen*liWidth+"px"});/*整个ul的宽度*/
	for(var i=0;i<liLen;i++){
		$("#pro li").eq(i).css({"left":i*liWidth+"px"});/*css() 方法设置或返回被选元素的一个或多个样式属性。*/		
		}
		
		//next右边按钮
	$(".pro_bottom .b_next").click(function(){
			show();
	})
	   //next右边按钮结束
	   
	   //prev左边按钮
	$(".pro_bottom .b_prev").click(function(){
		if(bool){
			bool=false;
			if(liLen>5){
				$(".pro_new li").eq(liLen-1).css({left:-liWidth+"px"}).animate({left:0},function(){
					$(this).prependTo("#pro ul");//prependTo() 方法在被选元素的开头（仍位于内部）插入指定内容。
				})
				for(var i=0;i<liLen-1;i++){
					$("#pro li").eq(i).animate({"left":liWidth*(i+1)+"px"},function(){
						bool=true;
					})
				}
			 }
		}
	})
	  ////prev左边按钮结束
	
	$(".pro_bottom .b_next,.pro_bottom .b_prev").mouseover(function(){
		clearInterval(lun);           /*鼠标移开就会自动清除*/
	})	
	$(".pro_bottom .b_next,.pro_bottom .b_prev").mouseout(function(){
		lun=setInterval(function(){  /*鼠标点击就会自动切换*/
			  show()},2000)
	})	
		
	function show(){
		if(bool){
			bool=false;
			if(liLen>5){
				$("#pro li").eq(0).animate({"left":-liWidth+"px"},function(){
					$("#pro li").eq(0).css({"left":liWidth*(liLen-1)+"px"}).appendTo("#pro ul");  //liWidth*(liLen-1)第liLen-1个索引值
					bool=true;
					});
				for( var i=1;i<liLen;i++){
					$("#pro li").eq(i).animate({"left":liWidth*(i-1)+"px"},function(){
						bool=true;
					})
				}
			  }
			}
		  }
		  lun=setInterval(function(){   /*自动轮播*/
			  
			  show()},2000)


			 //产品详情  小图切换大图 
	 $("#list_pro li").click(function(){
		 $(this).addClass("on").siblings().removeClass("on");
		 var Index=$(this).index();  //定义小产品图索引值
		 $(".pro_main .R_pro .top li").eq(Index).fadeIn().siblings().fadeOut(); 
	  })
	  
	  //定义当前位置on	 
	 $("#list_right li").click(function(){
		 $(this).addClass("on").siblings().removeClass("on");	 
		 })
});