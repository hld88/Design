// JavaScript Document
$(document).ready(function(){
	var Lun="";
	var bool=true;
	var length=$("#list_pro li").length; /*获取li的个数*/ 
	var liwidth=$("#list_pro li").eq(0).outerWidth();/*获取li的宽度*/
	$("#list_pro").eq(0).css({"width":(length-1)*liwidth+32+"px"});/*获取ul的宽度*/
	
	for(var i=0;i<length;i++){
		$("#list_pro li").eq(i).css({"left":i*(liwidth+16)+"px"});
		}
		//右边按钮
	 $(".pro_main .right .R_pro .bottom .next").click(function(){
		showa();
		})
		//右边按钮结束
	
	   //左边按钮开始
	  $(".pro_main .right .R_pro .bottom .prev").click(function(){
		  if(bool){
			  bool=false;
			  if(length>3){
			   $("#list_pro li").eq(length-1).css({"left":-(liwidth+16)+"px"}).animate({left:0},function()
				  {$(this).prependTo("#list_pro ul");})
				  for(var i=0;i<length-1;i++){
					   $("#list_pro li").eq(i).animate({left:(liwidth+16)*(i+1)+"px"},function(){
						   bool=true;
						   })
					  }
				  
				  }
			  }
		  
		  })//左边按钮结束
		  
	$(".pro_main .right .R_pro .bottom .next,.pro_main .right .R_pro .bottom .prev").mouseover(function(){
		clearInterval(Lun);
		})
	$(".pro_main .right .R_pro .bottom .next,.pro_main .right .R_pro .bottom .prev").mouseout(function(){
		setInterval(Lun);
		
		})
		
	
	function showa(){
		if(bool){
			bool=false;
			if(length>3){
				$("#list_pro li").eq(0).animate({"left":-(liwidth+16)+"px"},function(){
					$("#list_pro li").eq(0).css({"left":(liwidth+16)*(length-1)+"px"}).appendTo("#list_pro ul");
					bool=true;
					})
				for(var i=1;i<length;i++){
					$("#list_pro li").eq(i).animate({"left":(liwidth+16)*(i-1)+"px"},function(){
						bool=true;
						})
					}
				}
			};
		}
	     Lun=setInterval(function(){showa()},3000);
	});