function _(id){
	return document.getElementById(id);
}
var obj = document.getElementById('obj');
window.onload = function(){
	var play = "<img src='images/play.png' width='15%' alt='' id='img_play' />",
	stop = "<img src='images/stop.png' width='15%' alt='' id='img_stop' />",
	reset = "<img src='images/reset.png' width='15%' alt='' id='img_reset' />"
	var b_v = navigator.appVersion;
	var IE8 = b_v.search(/MSIE 8/i) != -1;
	var IE7 = b_v.search(/MSIE 7/i) != -1;
	if(IE8||IE7){
		if(obj.IsPlaying()){
   			obj.StopPlay();
   		}
   		var a = document.createElement('i')
   		a.setAttribute('id','play')
   		a.innerHTML = play+stop+reset
   		a.setAttribute('href','javascript:;')
   		document.getElementById('video-play').appendChild(a)
   		var t;
   		_('img_play').onclick = function(){
   			obj.play();
   			t = setInterval(time,1000) 
   			
   			
   		}
   		_('img_stop').onclick = function(){
			obj.StopPlay();
       		clearInterval(t)
		}
   		_('img_reset').onclick = function(){
   			obj.StopPlay();
       		clearInterval(t)
   			_("second").innerHTML = "00";
   			i.style.width = 0+"%";
   		}
   		var x = 0;
   		var span = document.createElement('span');
   		var i = document.createElement('i');
   		span.setAttribute('id','pro');
   		span.appendChild(i)
   		document.getElementById('video-play').appendChild(span)
   		var sp = document.createElement('span');
   		sp.setAttribute('class','sp_secode')
   		sp.innerHTML = "<span id='minute'>00</span>:<span id='second'>00</span>"; 
   		
   		document.getElementById('video-play').appendChild(sp)
   		function time(){
   			var sum = parseInt(obj.TotalFrames/24);
   			if(sum/x == 1){//
   				obj.stopPlay();
   				clearInterval(t)
   				x = 0;
   			}else{
   				_("second").innerHTML++;
   				x++
   				i.style.width = parseFloat(x/sum*100)+"%";
   				if(_("second").innerHTML<=59){
   					if(_("second").innerHTML<10){
   						_("second").innerHTML = "0"+_("second").innerHTML
       				}else{
       					_("second").innerHTML = _("second").innerHTML
       				}
   				}else{
   					var mSum = parseInt(_('minute').innerHTML)+1
   					if(parseInt(_('minute').innerHTML)<11){
   						_('minute').innerHTML ="0"+parseInt(mSum) ;
   					}else{
   						_('minute').innerHTML =mSum ;
   					}
   					
   					_("second").innerHTML = 00
   				}
   				
   			}
   		}
   	}
}	