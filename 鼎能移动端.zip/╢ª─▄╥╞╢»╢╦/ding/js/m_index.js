   
   $(document).ready(function(){
   	    $(window).resize(function(){	
   	   	$(".index_banner .bg li").css({"width":winWidth+"px"});
   	   	$(".product_list li").css({"width":p_width+"px"});
   	   	
   	   })
   	 
	  var len = $(".index_banner .bg li").length; //获取li的个数；
	  var winWidth=$(window).innerWidth();        //获取li在浏览器的宽度；	  
	  $(".index_banner .bg ul").css({"width":winWidth*len+"px"});//设置ul的宽度;
	  $(".index_banner .bg li").css({"width":winWidth+"px"});//设置li的宽度;
	  var iNow = 0;//当前on的位置
	  var bool=true;//设置开关
	  
	  
	var p_len = $(".product_list li").length;
	var p_width = $(window).innerWidth();
	var pNow = 0;
	var p_bool=true;
	$(".product_list ul").css({"width":p_len*p_width+"px"});
	$(".product_list li").css({"width":p_width+"px"});
	  
	  //	  进行向左边滑动li
      $(".index_banner .bg li").on("swipeleft",function(){
      	if(bool){
      		bool=false;
      		
      	    if(iNow > len-2){//防止循环进行，所以滑到第三张图片的时候，on的索引值要变为0开始；，否则的小于3的话都要+1
      		  iNow = 0;
      	     }else{
      		   iNow++
      	    }
      	     $(".index_banner .bg ul").animate({marginLeft:-winWidth+"px"},function(){
      		 $(".index_banner .bg ul li").eq(0).appendTo(".index_banner .bg ul");
      		 $(".index_banner .bg ul").css({"margin-left":0});
      		 bool=true;
      		 $(".index_banner .bottom li").removeClass('on').eq(iNow).addClass('on');
      		 
      		   //.removeClass('on')清除其他'on'.  
      	   })
      	 
      	 }
      })
     
     //进行向右边滑动
     $(".index_banner .bg li").on("swiperight",function(){
     	if(bool){
     		bool=false;
	     	if(iNow < 0){
	     		iNow=len-2;	
	     	}else{
	     	iNow--;
	     	}
	     	$(".index_banner .bg li").eq(len-1).prependTo(".index_banner .bg ul");
	     	$(".index_banner .bg ul").css({
	     		"margin-left":-winWidth+"px"}).animate({marginLeft:0},function(){
	     		bool=true;	
	     	$(".index_banner .bottom li").removeClass('on').eq(iNow).addClass('on');
	
	      })
     
     }

	})
     

	//向左边滑动
	$(".product_list li").on("swipeleft",function(){
	  if(p_bool){
	  	p_bool=false;
	  	
		if(pNow>p_len-2){
			pNow = 0;
		}
		else{
			pNow++;
		}
		  
		$(".product_list ul").animate({marginLeft:-p_width+"px"},function(){
		$(".product_list li").eq(0).appendTo(".product_list ul");
		$(".product_list ul").css({"margin-left":0});
		p_bool=true;
		
	    $(".product .page li").removeClass('on').eq(pNow).addClass('on');
		});
		
	
      }
	})
	
	
	//向右边滑动
	$(".product_list li").on("swiperight",function(){
	  if(p_bool){
	  	p_bool=false;
		if(pNow<0){
			pNow=p_len-2;
		}
		else{
			pNow--;
		}

		$(".product_list li").eq(p_len-1).prependTo(".product_list ul");
		$(".product_list ul").css({"margin-left":-p_width+"px"}).animate({marginLeft:0},function(){
			p_bool=true;
		$(".page li").removeClass('on').eq(pNow).addClass('on');
		});
		
		}
	})
  
  
})     
 
