

//  var inputfocus=function(element,value){
//		if(element.value == value){
//		element.value="";}
//		}
//	var inputblur=function(element,value){
//		if(element.value == ""){
//			element.value=value;			
//			}
//		
//		}

  var inputfocus=function(element,value){
  	  if(element.value == value){
  	  	 element.value ="";
  	  }
  	}
  var inputblur=function(element,value){
  	  if(element.value ==""){
  	  	element.value =value;
  	  }
  	
  }
