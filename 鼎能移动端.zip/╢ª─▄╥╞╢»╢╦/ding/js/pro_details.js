$(document).ready(function({
	aletr(123)
	
}))
